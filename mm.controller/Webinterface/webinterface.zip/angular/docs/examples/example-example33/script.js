  angular.module('debounceExample', [])
    .controller('ExampleController', ['$scope', function($scope) {
      $scope.user = {};
    }]);